#include <iostream>
#include <algorithm>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <vector>
#include <cmath>
#include <string>
#include <numeric>
#include <map>
#include <iomanip>
#include <set>

using namespace std;

// int main () {
//    string s;
//    int i,j, z= 0;
//    getline(cin, s);
//    for (i = 0; i < s.size(); i++) {
//        if (s[i] == ' ' || i == s.size() - 1) {
//         for (j = z; j <= i; j++ ) {
//             cout << s[j];
//         }
//         z = i+1;
//         cout << endl;
//    }
//  } 
// }

// int main() {
//     int n,i,a[100];
//     float ave = 0;
//     cin >> n;
//     for ( i = 0; i < n; i++ ) {
//         cin >> a[i];
//         ave += a[i];
//     }
//     ave /= n;
//     cout << setprecision(3) << fixed << ave;
// }